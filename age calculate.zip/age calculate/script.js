function calculateAge() {
    var dob = new Date(document.getElementById('dob').value);
    var today = new Date();
    
    var age = today.getFullYear() - dob.getFullYear();
    var monthDiff = today.getMonth() - dob.getMonth();
    var dayDiff = today.getDate() - dob.getDate();

    if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
        age--;
        monthDiff += 12;
    }

    var years = age;
    var months = monthDiff;
    var days = dayDiff < 0 ? daysInMonth(today.getMonth() - 1, today.getFullYear()) - dob.getDate() + today.getDate() : dayDiff;

    document.getElementById('result').innerHTML = "Your age is: " + years + " years, " + months + " months, and " + days + " days.";
}

function resetForm() {
    document.getElementById('dob').value = '';
    document.getElementById('result').innerHTML = '';
}

function daysInMonth(month, year) {
    return new Date(year, month + 1, 0).getDate();
}
